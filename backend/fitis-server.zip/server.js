import express from 'express';
import cors from 'cors';
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import fs from 'fs';
import { BrevoClient } from '@getbrevo/brevo';
import crypto from 'crypto';
import otplib from 'otplib';
const authenticator = otplib.authenticator || otplib.default.authenticator;
import QRCode from 'qrcode';



const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.resolve(__dirname, '.env') });

const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret_key';

const app = express();
const port = process.env.PORT || 5004;

app.use(cors({
  origin: [
    // Local development
    'http://localhost:3000',
    'http://localhost:3001',
    'http://localhost:3002',
    'http://localhost:5173',
    'http://localhost:3005',
    // Production
    'https://qfactor.lk',
    'https://www.qfactor.lk',
  ],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));
app.use(express.json());

// Expose uploads directory statically
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

// Multer Storage Configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    let dest = 'uploads/';
    if (req.path.includes('/upload/hero')) {
      dest += 'hero';
    } else if (req.path.includes('/upload/favicon')) {
      dest += 'favicon';
    } else if (req.path.includes('/upload/leadership')) {
      dest += 'leadership';
    } else if (req.path.includes('/upload/news-banner')) {
      dest += 'news-banner';
    } else if (req.path.includes('/upload/news-pdf')) {
      dest += 'news-pdf';
    } else if (req.path.includes('/upload/newsletter-pdf') || req.path.includes('/upload/newsletter-cover')) {
      dest += 'newsletters';
    } else if (req.path.includes('/gallery') || req.path.includes('/upload/gallery')) {
      dest += 'gallery';
    } else if (req.path.includes('/upload/event-flyer')) {
      dest += 'events';
    } else if (req.path.includes('/upload/program-banner')) {
      dest += 'programs';
    } else if (req.path.includes('/upload/chairman-photo')) {
      dest += 'chairman';
    } else if (req.path.includes('/upload/secretariat-photo')) {
      dest += 'secretariat';
    } else if (req.path.includes('/upload/partner-logo')) {
      dest += 'partners';
    } else if (req.path.includes('/upload/member-benefit-logo')) {
      dest += 'benefits';
    } else if (req.path.includes('/upload/chapter-icon')) {
      dest += 'chapters';
    } else if (req.path.includes('/admin/community-members')) {
      dest += 'community';
    }
    // Ensure directory exists
    fs.mkdirSync(path.join(process.cwd(), dest), { recursive: true });
    cb(null, path.join(process.cwd(), dest));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const uploadHero = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Invalid file type for hero media'));
  }
});

const uploadFavicon = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 }, // 2MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/x-icon', 'image/png', 'image/svg+xml'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Invalid file type for favicon'));
  }
});

const uploadLeadership = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Invalid file type for leadership image'));
  }
});

const uploadNewsBanner = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Invalid file type for banner image'));
  }
});

const uploadNewsPdf = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') cb(null, true);
    else cb(new Error('Invalid file type for PDF'));
  }
});

const uploadGallery = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB per image
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Invalid file type for gallery image'));
  }
});

const uploadEventFlyer = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Invalid file type for event flyer'));
  }
});

const uploadProgramBanner = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Invalid file type for program banner'));
  }
});

const uploadNewsletterPdf = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') cb(null, true);
    else cb(new Error('Invalid file type for PDF'));
  }
});

const uploadNewsletterCover = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Invalid file type for newsletter cover'));
  }
});

const uploadChairmanPhoto = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Invalid file type for chairman photo'));
  }
});

const uploadSecretariatPhoto = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Invalid file type for secretariat photo'));
  }
});

const uploadPartnerLogo = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Invalid file type for partner logo'));
  }
});

const uploadBenefitLogo = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Invalid file type for benefit logo'));
  }
});

const uploadChapterIcon = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Invalid file type for chapter icon'));
  }
});

// Database connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || '127.0.0.1',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'fitis',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

pool.query(`
  CREATE TABLE IF NOT EXISTS newsletters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    pdf_url VARCHAR(500) NOT NULL,
    cover_image_url VARCHAR(500) NULL,
    published_date DATE,
    status ENUM('draft', 'published') DEFAULT 'draft',
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  )
`).then(() => console.log('Newsletters table ensured')).catch(err => console.error('Error creating newsletters table:', err));

pool.query(`ALTER TABLE site_settings ADD COLUMN leadership_year VARCHAR(50) DEFAULT '2023/2024'`).then(() => console.log('Added leadership_year')).catch(() => {});


// Brevo (Sendinblue) API Client for Transactional Emails
const brevoClient = new BrevoClient({
  apiKey: process.env.BREVO_API_KEY || ''
});

/**
 * Sends a transactional email via the Brevo API.
 * @param {string} toEmail      - Recipient email address
 * @param {string} toName       - Recipient display name
 * @param {string} subject      - Email subject
 * @param {string} htmlContent  - HTML body of the email
 */
async function sendBrevoEmail(toEmail, toName, subject, htmlContent) {
  return brevoClient.transactionalEmails.sendTransacEmail({
    sender: {
      name: process.env.BREVO_SENDER_NAME || 'FITIS',
      email: process.env.BREVO_SENDER_EMAIL || 'noreply@qfactor.lk'
    },
    to: [{ email: toEmail, name: toName }],
    subject,
    htmlContent
  });
}


// Test DB Connection Route
app.get('/api/health', async (req, res) => {
  try {
    const connection = await pool.getConnection();
    await connection.ping();
    connection.release();
    res.json({ ok: true, status: 'success', message: 'Connected to MySQL Database' });
  } catch (error) {
    console.error('Database connection failed:', error);
    res.status(500).json({ ok: false, status: 'error', message: 'Database connection failed' });
  }
});

// POST /api/contact/chapter - Chapter contact inquiry endpoint
app.post('/api/contact/chapter', async (req, res) => {
  const { name, email, phone, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Name, email, and message are required' });
  }

  try {
    await sendBrevoEmail(
      'info@fitis.lk', 
      'FITIS Info',
      `New Chapter Inquiry from ${name}`,
      `
        <h3>New Chapter Inquiry</h3>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Phone:</strong> ${phone || 'N/A'}</p>
        <hr/>
        <p><strong>Message:</strong></p>
        <p>${message}</p>
      `
    );
    res.json({ success: true, message: 'Inquiry sent successfully' });
  } catch (error) {
    console.error('Error sending chapter inquiry email:', error);
    res.status(500).json({ error: 'Failed to send inquiry' });
  }
});

// Authentication Middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (token == null) return res.status(401).json({ message: 'Unauthorized' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(401).json({ message: 'Unauthorized' });
    req.user = user;
    next();
  });
};

// Admin Login
app.post('/api/auth/login', async (req, res) => {
  const { username, password, otpToken } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  try {
    const [rows] = await pool.execute('SELECT * FROM admin_users WHERE username = ?', [username]);
    if (rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = rows[0];
    if (user.password !== password) {
       return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (!user.two_factor_secret) {
      // Return a flag indicating 2FA setup is required
      return res.json({ requires2FASetup: true, message: '2FA setup required' });
    }

    if (!otpToken) {
      return res.status(400).json({ error: 'Google Authenticator OTP is required' });
    }

    const isValid = authenticator.verify({ token: otpToken, secret: user.two_factor_secret });
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid OTP token' });
    }

    // Create JWT
    const token = jwt.sign(
      { id: user.id, username: user.username },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    // Success
    res.json({ message: 'Login successful', token, user: { id: user.id, username: user.username } });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/auth/community/set-password - Setup password from admin email link
app.post('/api/auth/community/set-password', async (req, res) => {
  const { email, token, new_password } = req.body;

  if (!email || !token || !new_password) {
    return res.status(400).json({ error: 'Email, token, and new password are required' });
  }

  try {
    const [otpRows] = await pool.execute('SELECT * FROM otp_verifications WHERE email = ? AND otp = ? AND expires_at > NOW()', [email, token]);
    if (otpRows.length === 0) {
      return res.status(400).json({ error: 'Invalid or expired setup token' });
    }

    const [userRows] = await pool.execute('SELECT * FROM member_community_requests WHERE official_email = ?', [email]);
    if (userRows.length === 0) {
      return res.status(404).json({ error: 'Account not found' });
    }

    await pool.execute('UPDATE member_community_requests SET password = ?, status = "Approved" WHERE official_email = ?', [new_password, email]);
    await pool.execute('DELETE FROM otp_verifications WHERE email = ?', [email]);

    res.json({ message: 'Password set successfully' });
  } catch (err) {
    console.error('Set password error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// OTP Verification Endpoints
app.post('/api/membership/send-otp', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email is required' });

  try {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Store in DB
    await pool.execute(
      'INSERT INTO otp_verifications (email, otp, expires_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE otp = ?, expires_at = ?',
      [email, otp, expiresAt, otp, expiresAt]
    );

    // Send OTP email via Brevo
    await sendBrevoEmail(
      email,
      email,
      'Your OTP for FITIS Membership Application',
      `
        <div style="font-family: sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
          <h2 style="color: #00529B;">FITIS Membership OTP</h2>
          <p>Thank you for starting your membership application with FITIS.</p>
          <p>Please use the following One-Time Password (OTP) to verify your email address. This code is valid for 10 minutes.</p>
          <div style="background: #f4f4f4; padding: 15px; text-align: center; font-size: 24px; font-bold; letter-spacing: 5px; color: #333; border-radius: 5px; margin: 20px 0;">
            ${otp}
          </div>
          <p>If you did not request this code, please ignore this email.</p>
          <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;" />
          <p style="font-size: 12px; color: #777;">Federation of Information Technology Industry Sri Lanka (FITIS)</p>
        </div>
      `
    );
    res.json({ message: 'OTP sent successfully' });
  } catch (error) {
    console.error('Error sending OTP:', error);
    res.status(500).json({ error: 'Failed to send OTP' });
  }
});

app.post('/api/membership/verify-otp', async (req, res) => {
  const { email, otp } = req.body;
  if (!email || !otp) return res.status(400).json({ error: 'Email and OTP are required' });

  try {
    const [rows] = await pool.execute(
      'SELECT * FROM otp_verifications WHERE email = ? AND otp = ? AND expires_at > NOW()',
      [email, otp]
    );

    if (rows.length === 0) {
      return res.status(400).json({ error: 'Invalid or expired OTP' });
    }

    // Success - optionally delete the OTP record
    await pool.execute('DELETE FROM otp_verifications WHERE email = ?', [email]);

    res.json({ message: 'OTP verified successfully' });
  } catch (error) {
    console.error('Error verifying OTP:', error);
    res.status(500).json({ error: 'Failed to verify OTP' });
  }
});


// POST /api/membership/apply - Public endpoint for new member applications
app.post('/api/membership/apply', multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const dir = path.join(process.cwd(), 'uploads', 'memberships');
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => cb(null, Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname))
  })
}).fields([
  { name: 'business_registration', maxCount: 1 },
  { name: 'audited_accounts', maxCount: 1 },
  { name: 'company_profile', maxCount: 1 },
  { name: 'form_20', maxCount: 1 }
]), async (req, res) => {
  try {
    const data = req.body;

    const fileUrl = (fieldname) => {
      if (req.files && req.files[fieldname] && req.files[fieldname][0]) {
        return `/uploads/memberships/${req.files[fieldname][0].filename}`;
      }
      return null;
    };

    const br_url = fileUrl('business_registration');
    const aa_url = fileUrl('audited_accounts');
    const cp_url = fileUrl('company_profile');
    const form20_url = fileUrl('form_20');

    const sql = `
      INSERT INTO member_applications (
        primary_chapter, chapters_applied, company_name, membership_category, ceo_name, company_address,
        phone, fax, website, email, br_number, year_incorporation, boi_no, ownership_local, ownership_foreign,
        business_activities, industry_focus, revenue_local, revenue_foreign, employees_count,
        primary_nominee, secondary_nominee, business_registration, audited_accounts, company_profile, form_20,
        declaration_applicant_name, declaration_applicant_designation, declaration_date, agree_checkbox, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')
    `;

    const values = [
      data.primary_chapter, data.chapters_applied_json, data.company_name, data.membership_category, data.ceo_name, data.company_address,
      data.phone, data.fax, data.website, data.email, data.br_number, data.year_incorporation, data.boi_no, data.ownership_local, data.ownership_foreign,
      data.business_activities, data.industry_focus_json, data.revenue_local, data.revenue_foreign, data.employees_count,
      data.primary_nominee_json, data.secondary_nominee_json,
      br_url, aa_url, cp_url, form20_url,
      data.declaration_applicant_name, data.declaration_applicant_designation, data.declaration_date, data.agree_checkbox === 'true' ? 1 : 0
    ];

    await pool.query(sql, values);
    res.json({ success: true });
  } catch (error) {
    console.error('Membership application error:', error);
    res.status(500).json({ error: error.message });
  }
});

// POST /api/community/apply - Public endpoint for new member community applications
app.post('/api/community/apply', multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const dir = path.join(process.cwd(), 'uploads', 'community');
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => cb(null, Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname))
  })
}).fields([
  { name: 'company_logo', maxCount: 1 },
  { name: 'rep_image', maxCount: 1 }
]), async (req, res) => {
  try {
    const data = req.body;

    const fileUrl = (fieldname) => {
      if (req.files && req.files[fieldname] && req.files[fieldname][0]) {
        return `/uploads/community/${req.files[fieldname][0].filename}`;
      }
      return null;
    };

    const logo_url = fileUrl('company_logo');
    const rep_img_url = fileUrl('rep_image');

    const sql = `
      INSERT INTO member_community_requests (
        company_name, primary_chapter, secondary_chapter, fitis_membership_id, services, company_logo_url, company_id, official_email,
        company_linkedin, website_link, rep_image_url, rep_name,
        rep_email, rep_mobile, rep_designation, password, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')
    `;

    const values = [
      data.company_name, data.primary_chapter, data.secondary_chapter, data.fitis_membership_id, data.services, logo_url, data.company_id, data.official_email,
      data.company_linkedin, data.website_link, rep_img_url, data.rep_name,
      data.rep_email, data.rep_mobile, data.rep_designation, data.password
    ];

    await pool.query(sql, values);
    res.json({ success: true });
  } catch (error) {
    console.error('Community application error:', error);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/community-members - Public endpoint to get approved community members
app.get('/api/community-members', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT id, company_name, official_email, company_id, company_logo_url, services, website_link, company_linkedin, primary_chapter, secondary_chapter, rep_name, rep_designation, rep_email, rep_mobile, rep_image_url, fitis_membership_id FROM member_community_requests WHERE status = "Approved" ORDER BY created_at DESC');
    res.json(rows);

  } catch (error) {
    console.error('Error fetching community members:', error);
    res.status(500).json({ error: 'Failed to fetch community members' });
  }
});

// GET /api/community-members/:id - Public endpoint to get a single approved member

app.get('/api/community-members/:id', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT id, company_name, official_email, company_id, company_logo_url, services, website_link, company_linkedin, primary_chapter, secondary_chapter, rep_name, rep_designation, rep_email, rep_mobile, rep_image_url, fitis_membership_id FROM member_community_requests WHERE id = ? AND status = "Approved"', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Member not found' });
    res.json(rows[0]);

  } catch (error) {
    console.error('Error fetching member details:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/community-members/:id/posts - Public endpoint to get APPROVED posts for a member
app.get('/api/community-members/:id/posts', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM member_posts WHERE member_id = ? AND status = \'Approved\' ORDER BY created_at DESC', [req.params.id]);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching member posts:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/community/posts - Protected endpoint to create a post (defaults to Pending for admin approval)
app.post('/api/community/posts', authenticateToken, multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const dir = path.join(process.cwd(), 'uploads', 'posts');
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => cb(null, Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname))
  })
}).single('image'), async (req, res) => {
  try {
    const { content } = req.body;
    const member_id = req.user.id;
    const image_url = req.file ? `/uploads/posts/${req.file.filename}` : null;

    if (!content && !image_url) {
      return res.status(400).json({ error: 'Post content or image is required' });
    }

    const [result] = await pool.execute(
      'INSERT INTO member_posts (member_id, content, image_url, status) VALUES (?, ?, ?, \'Pending\')',
      [member_id, content, image_url]
    );

    res.json({ id: result.insertId, member_id, content, image_url, status: 'Pending', created_at: new Date() });
  } catch (error) {
    console.error('Error creating post:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/community/my-posts - Protected endpoint for a member to see their own posts (all statuses)
app.get('/api/community/my-posts', authenticateToken, async (req, res) => {
  try {
    const member_id = req.user.id;
    const [rows] = await pool.execute('SELECT * FROM member_posts WHERE member_id = ? ORDER BY created_at DESC', [member_id]);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching own posts:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// DELETE /api/community/posts/:id - Protected endpoint to delete a post
app.delete('/api/community/posts/:id', authenticateToken, async (req, res) => {
  try {
    const post_id = req.params.id;
    const member_id = req.user.id;

    // Ensure member owns the post
    const [rows] = await pool.execute('SELECT member_id FROM member_posts WHERE id = ?', [post_id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Post not found' });
    if (rows[0].member_id !== member_id) return res.status(403).json({ error: 'Unauthorized to delete this post' });

    await pool.execute('DELETE FROM member_posts WHERE id = ?', [post_id]);
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting post:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ADMIN: GET /api/admin/wall-posts - Get all wall posts with member info
app.get('/api/admin/wall-posts', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT mp.*, m.company_name, m.company_logo_url, m.official_email
      FROM member_posts mp
      JOIN member_community_requests m ON mp.member_id = m.id
      ORDER BY mp.created_at DESC
    `);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching admin wall posts:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ADMIN: PUT /api/admin/wall-posts/:id - Approve or take down a post
app.put('/api/admin/wall-posts/:id', authenticateToken, async (req, res) => {
  try {
    const { status } = req.body;
    const allowed = ['Pending', 'Approved', 'TakenDown'];
    if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status' });
    await pool.execute('UPDATE member_posts SET status = ? WHERE id = ?', [status, req.params.id]);
    res.json({ success: true });
  } catch (error) {
    console.error('Error updating post status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ADMIN: DELETE /api/admin/wall-posts/:id - Permanently delete a post
app.delete('/api/admin/wall-posts/:id', authenticateToken, async (req, res) => {
  try {
    await pool.execute('DELETE FROM member_posts WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting post (admin):', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/community/profile - Member gets their own profile data
app.get('/api/community/profile', authenticateToken, async (req, res) => {
  try {
    const member_id = req.user.id;
    const [rows] = await pool.execute('SELECT * FROM member_community_requests WHERE id = ?', [member_id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Profile not found' });
    
    // Do not return password
    const { password, ...safeData } = rows[0];
    res.json(safeData);
  } catch (error) {
    console.error('Error fetching member profile:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/community/profile-update - Member submits a profile update for approval
app.post('/api/community/profile-update', authenticateToken, async (req, res) => {
  try {
    const member_id = req.user.id;
    const updated_data = req.body;

    // Check if there's already a pending update
    const [pending] = await pool.execute('SELECT id FROM member_profile_updates WHERE member_id = ? AND status = "Pending"', [member_id]);
    if (pending.length > 0) {
      return res.status(400).json({ error: 'You already have a pending profile update request' });
    }

    await pool.execute(
      'INSERT INTO member_profile_updates (member_id, updated_data) VALUES (?, ?)',
      [member_id, JSON.stringify(updated_data)]
    );

    res.json({ message: 'Profile update request submitted successfully' });
  } catch (error) {
    console.error('Error submitting profile update:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/community/profile-update/status - Member checks their update status
app.get('/api/community/profile-update/status', authenticateToken, async (req, res) => {
  try {
    const member_id = req.user.id;
    const [rows] = await pool.execute('SELECT * FROM member_profile_updates WHERE member_id = ? ORDER BY created_at DESC LIMIT 1', [member_id]);
    res.json(rows[0] || null);
  } catch (error) {
    console.error('Error fetching update status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ADMIN ENDPOINTS FOR PROFILE UPDATES
app.get('/api/admin/profile-updates', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT u.*, m.company_name, m.official_email 
      FROM member_profile_updates u
      JOIN member_community_requests m ON u.member_id = m.id
      WHERE u.status = "Pending"
      ORDER BY u.created_at DESC
    `);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching profile updates:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/admin/profile-updates/:id/approve', async (req, res) => {
  try {
    const update_id = req.params.id;
    
    // Get the update data
    const [updates] = await pool.execute('SELECT * FROM member_profile_updates WHERE id = ?', [update_id]);
    if (updates.length === 0) return res.status(404).json({ error: 'Update request not found' });
    
    const update = updates[0];
    const data = typeof update.updated_data === 'string' ? JSON.parse(update.updated_data) : update.updated_data;
    
    // Apply updates to member_community_requests
    const allowedFields = [
      'company_name', 'official_email', 'company_id', 'company_logo_url', 'services', 
      'website_link', 'company_linkedin', 'primary_chapter', 'secondary_chapter', 
      'rep_name', 'rep_designation', 'rep_email', 'rep_mobile', 'rep_image_url'
    ];

    let updateQuery = 'UPDATE member_community_requests SET ';
    const updateValues = [];
    const fieldsToUpdate = [];

    Object.keys(data).forEach(key => {
      if (allowedFields.includes(key)) {
        fieldsToUpdate.push(`${key} = ?`);
        updateValues.push(data[key]);
      }
    });

    if (fieldsToUpdate.length === 0) return res.status(400).json({ error: 'No valid fields to update' });

    updateQuery += fieldsToUpdate.join(', ') + ' WHERE id = ?';
    updateValues.push(update.member_id);

    await pool.execute(updateQuery, updateValues);
    
    // Mark as approved
    await pool.execute('UPDATE member_profile_updates SET status = "Approved" WHERE id = ?', [update_id]);
    
    res.json({ message: 'Profile update approved and applied successfully' });
  } catch (error) {
    console.error('Error approving profile update:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/admin/profile-updates/:id/reject', async (req, res) => {
  try {
    const update_id = req.params.id;
    await pool.execute('UPDATE member_profile_updates SET status = "Rejected" WHERE id = ?', [update_id]);
    res.json({ message: 'Profile update rejected' });
  } catch (error) {
    console.error('Error rejecting profile update:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// =====================================================
// ADMIN NOTIFICATIONS (Admin → Member Messages)
// =====================================================

// ADMIN: POST /api/admin/notifications - Send a notification/message to a member
app.post('/api/admin/notifications', authenticateToken, async (req, res) => {
  try {
    const { member_id, title, message } = req.body;
    if (!member_id || !title || !message) {
      return res.status(400).json({ error: 'member_id, title, and message are required' });
    }
    const [result] = await pool.execute(
      'INSERT INTO admin_notifications (member_id, title, message) VALUES (?, ?, ?)',
      [member_id, title, message]
    );
    res.json({ id: result.insertId, member_id, title, message, is_read: false, created_at: new Date() });
  } catch (error) {
    console.error('Error sending notification:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ADMIN: GET /api/admin/notifications/:member_id - Get all notifications sent to a specific member
app.get('/api/admin/notifications/:member_id', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM admin_notifications WHERE member_id = ? ORDER BY created_at DESC',
      [req.params.member_id]
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching notifications:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ADMIN: DELETE /api/admin/notifications/:id - Delete a notification
app.delete('/api/admin/notifications/:id', authenticateToken, async (req, res) => {
  try {
    await pool.execute('DELETE FROM admin_notifications WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting notification:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// MEMBER: GET /api/community/notifications - Fetch all notifications for the logged-in member
app.get('/api/community/notifications', authenticateToken, async (req, res) => {
  try {
    const member_id = req.user.id;
    const [rows] = await pool.execute(
      'SELECT * FROM admin_notifications WHERE member_id = ? ORDER BY created_at DESC',
      [member_id]
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching member notifications:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// MEMBER: PUT /api/community/notifications/:id/read - Mark a notification as read
app.put('/api/community/notifications/:id/read', authenticateToken, async (req, res) => {
  try {
    const member_id = req.user.id;
    await pool.execute(
      'UPDATE admin_notifications SET is_read = TRUE WHERE id = ? AND member_id = ?',
      [req.params.id, member_id]
    );
    res.json({ success: true });
  } catch (error) {
    console.error('Error marking notification as read:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// MEMBER: PUT /api/community/notifications/read-all - Mark all notifications as read
app.put('/api/community/notifications/read-all', authenticateToken, async (req, res) => {
  try {
    const member_id = req.user.id;
    await pool.execute(
      'UPDATE admin_notifications SET is_read = TRUE WHERE member_id = ?',
      [member_id]
    );
    res.json({ success: true });
  } catch (error) {
    console.error('Error marking all notifications as read:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/auth/community/reset-password - Reset password using OTP
app.post('/api/auth/community/reset-password', async (req, res) => {
  const { email, otp, new_password } = req.body;
  if (!email || !otp || !new_password) return res.status(400).json({ error: 'Missing required fields' });

  try {
    const [otpRows] = await pool.execute(
      'SELECT * FROM otp_verifications WHERE email = ? AND otp = ? AND expires_at > NOW()',
      [email, otp]
    );

    if (otpRows.length === 0) {
      return res.status(400).json({ error: 'Invalid or expired OTP' });
    }

    const [userRows] = await pool.execute('SELECT id FROM member_community_requests WHERE official_email = ?', [email]);
    if (userRows.length === 0) {
      return res.status(404).json({ error: 'No member account found with this email' });
    }

    await pool.execute('UPDATE member_community_requests SET password = ? WHERE official_email = ?', [new_password, email]);
    await pool.execute('DELETE FROM otp_verifications WHERE email = ?', [email]);

    res.json({ message: 'Password reset successful' });
  } catch (err) {
    console.error('Reset password error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/auth/community-login - Public endpoint for community members to login
app.post('/api/auth/community-login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  try {
    const [rows] = await pool.execute('SELECT * FROM member_community_requests WHERE official_email = ?', [email]);
    if (rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = rows[0];
    if (user.password !== password) {
       return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (user.status === 'Pending') {
      return res.status(403).json({ error: 'Your account is pending approval by the administration.' });
    }
    if (user.status === 'Rejected') {
      return res.status(403).json({ error: 'Your account request was rejected.' });
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 mins
    await pool.execute(
      'INSERT INTO otp_verifications (email, otp, expires_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE otp = ?, expires_at = ?',
      [email, otp, expiresAt, otp, expiresAt]
    );

    await sendBrevoEmail(
      email, 
      user.company_name || 'Member', 
      'FITIS Login Verification Code', 
      `Your FITIS login verification code is: <strong style="font-size:24px;">${otp}</strong><br/>It expires in 15 minutes.`
    );

    res.json({ message: 'OTP sent to email', requiresOtp: true });
  } catch (error) {
    console.error('Community Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/auth/community-login/verify - Verify OTP and login
app.post('/api/auth/community-login/verify', async (req, res) => {
  const { email, password, otp } = req.body;

  if (!email || !password || !otp) {
    return res.status(400).json({ error: 'Email, password, and OTP are required' });
  }

  try {
    const [rows] = await pool.execute('SELECT * FROM member_community_requests WHERE official_email = ?', [email]);
    if (rows.length === 0) return res.status(401).json({ error: 'Invalid credentials' });
    const user = rows[0];
    if (user.password !== password) return res.status(401).json({ error: 'Invalid credentials' });

    // Verify OTP
    const [otpRows] = await pool.execute('SELECT * FROM otp_verifications WHERE email = ? AND otp = ? AND expires_at > NOW()', [email, otp]);
    if (otpRows.length === 0) {
      return res.status(400).json({ error: 'Invalid or expired OTP' });
    }

    // Clear OTP
    await pool.execute('DELETE FROM otp_verifications WHERE email = ?', [email]);

    // Create JWT
    const token = jwt.sign(
      { id: user.id, company_name: user.company_name, email: user.official_email },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({ message: 'Login successful', token, user: { id: user.id, company_name: user.company_name, email: user.official_email } });
  } catch (error) {
    console.error('Community Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// Allowed tables and columns for generic CRUD to prevent SQL injection
const TABLE_COLUMNS = {
  news: ['title', 'slug', 'excerpt', 'content', 'banner_image_url', 'pdf_url', 'category', 'status', 'publish_date', 'author'],
  events: ['title', 'flyer_image_url', 'venue', 'event_date', 'start_time', 'end_time', 'timezone', 'rsvp_open', 'short_description', 'details_url', 'facebook_url', 'twitter_url', 'linkedin_url', 'status'],
  leadership_members: ['name', 'designation', 'type', 'image_url', 'linkedin_url', 'hierarchy_level', 'seat', 'year_start', 'year_end', 'sort_order', 'status'],
  partners: ['name', 'category', 'logo_url', 'website_url', 'sort_order', 'status'],
  newsletter_subscribers: ['email'],
  programs: ['title', 'slug', 'description', 'banner_image_url', 'read_more_url', 'status', 'sort_order'],
    secretariat_team: ['name', 'role', 'photo_url', 'linkedin_url', 'facebook_url', 'sort_order', 'status'],
  member_applications: ['primary_chapter', 'chapters_applied', 'company_name', 'membership_category', 'ceo_name', 'company_address', 'phone', 'fax', 'website', 'email', 'br_number', 'year_incorporation', 'boi_no', 'ownership_local', 'ownership_foreign', 'business_activities', 'industry_focus', 'revenue_local', 'revenue_foreign', 'employees_count', 'primary_nominee', 'secondary_nominee', 'business_registration', 'audited_accounts', 'company_profile', 'form_20', 'declaration_applicant_name', 'declaration_applicant_designation', 'declaration_date', 'agree_checkbox', 'status'],
  member_benefits: ['brand_name', 'benefit_title', 'category', 'offer_text', 'description', 'terms', 'link_url', 'logo_url', 'sort_order', 'status'],
  member_community_requests: ['company_name', 'primary_chapter', 'secondary_chapter', 'fitis_membership_id', 'services', 'company_logo_url', 'company_id', 'official_email', 'company_linkedin', 'website_link', 'rep_image_url', 'rep_name', 'rep_email', 'rep_mobile', 'rep_designation', 'password', 'status'],
  newsletters: ['title', 'pdf_url', 'cover_image_url', 'published_date', 'status', 'sort_order']
};
const ALLOWED_TABLES = Object.keys(TABLE_COLUMNS);

// Public Site Settings
app.get('/api/site-settings', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM site_settings WHERE id = 1');
    if (rows.length === 0) return res.status(404).json({ error: 'Settings not found' });
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching site settings:', error);
    res.status(500).json({ error: 'Failed to fetch settings' });
  }
});

// Admin Site Settings (Protected)
app.get('/api/admin/site-settings', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM site_settings WHERE id = 1');
    if (rows.length === 0) return res.status(404).json({ error: 'Settings not found' });
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching site settings:', error);
    res.status(500).json({ error: 'Failed to fetch settings' });
  }
});

app.put('/api/admin/site-settings', authenticateToken, async (req, res) => {
  const { site_email, site_phone, site_location, hero_type, hero_url, header_logo_url, footer_logo_url, favicon_url, facebook_url, instagram_url, linkedin_url, twitter_url, youtube_url, leadership_year } = req.body;
  try {
    const [existing] = await pool.execute('SELECT id FROM site_settings WHERE id = 1');
    if (existing.length === 0) {
      await pool.execute(
        `INSERT INTO site_settings (id, site_email, site_phone, site_location, hero_type, hero_url, header_logo_url, footer_logo_url, favicon_url, facebook_url, instagram_url, linkedin_url, twitter_url, youtube_url, leadership_year)
         VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [site_email, site_phone, site_location, hero_type, hero_url, header_logo_url, footer_logo_url, favicon_url, facebook_url, instagram_url, linkedin_url, twitter_url, youtube_url, leadership_year]
      );
    } else {
      await pool.execute(
        `UPDATE site_settings
         SET site_email=?, site_phone=?, site_location=?, hero_type=?, hero_url=?, header_logo_url=?, footer_logo_url=?, favicon_url=?, facebook_url=?, instagram_url=?, linkedin_url=?, twitter_url=?, youtube_url=?, leadership_year=COALESCE(?, leadership_year)
         WHERE id=1`,
        [site_email, site_phone, site_location, hero_type, hero_url, header_logo_url, footer_logo_url, favicon_url, facebook_url, instagram_url, linkedin_url, twitter_url, youtube_url, leadership_year]
      );
    }
    res.json({ message: 'Settings updated successfully' });
  } catch (error) {
    console.error('Error updating settings:', error);
    res.status(500).json({ error: 'Failed to update settings' });
  }
});

app.put('/api/admin/site-settings/leadership-year', authenticateToken, async (req, res) => {
  try {
    await pool.execute('UPDATE site_settings SET leadership_year = ? WHERE id = 1', [req.body.leadership_year]);
    res.json({ success: true });
  } catch (error) {
    console.error('Error updating leadership year:', error);
    res.status(500).json({ error: 'Failed to update leadership year' });
  }
});
// Privacy Policy Public
app.get('/api/privacy-policy', async (req, res) => {
  try {
    const [pageRows] = await pool.execute('SELECT * FROM privacy_policy_page WHERE id = 1 AND status = "published"');
    if (pageRows.length === 0) return res.status(404).json({ error: 'Privacy Policy not found or not published' });

    const [sectionRows] = await pool.execute('SELECT * FROM privacy_policy_sections WHERE page_id = 1 ORDER BY sort_order ASC, id ASC');
    res.json({ ...pageRows[0], sections: sectionRows });
  } catch (error) {
    console.error('Error fetching privacy policy:', error);
    res.status(500).json({ error: 'Failed to fetch privacy policy' });
  }
});

// Admin Privacy Policy (Protected)
app.get('/api/admin/privacy-policy', authenticateToken, async (req, res) => {
  try {
    const [pageRows] = await pool.execute('SELECT * FROM privacy_policy_page WHERE id = 1');
    if (pageRows.length === 0) return res.status(404).json({ error: 'Privacy Policy not found' });

    const [sectionRows] = await pool.execute('SELECT * FROM privacy_policy_sections WHERE page_id = 1 ORDER BY sort_order ASC, id ASC');
    res.json({ ...pageRows[0], sections: sectionRows });
  } catch (error) {
    console.error('Error fetching privacy policy:', error);
    res.status(500).json({ error: 'Failed to fetch privacy policy' });
  }
});

app.put('/api/admin/privacy-policy', authenticateToken, async (req, res) => {
  const { page_title, effective_date, status, sections } = req.body;
  const dbConnection = await pool.getConnection();
  try {
    await dbConnection.beginTransaction();

    const [existing] = await dbConnection.execute('SELECT id FROM privacy_policy_page WHERE id = 1');
    const effDate = effective_date ? new Date(effective_date).toISOString().split('T')[0] : null;

    if (existing.length === 0) {
      await dbConnection.execute(
        `INSERT INTO privacy_policy_page (id, page_title, effective_date, status) VALUES (1, ?, ?, ?)`,
        [page_title || 'PRIVACY POLICY', effDate, status || 'published']
      );
    } else {
      await dbConnection.execute(
        `UPDATE privacy_policy_page SET page_title=?, effective_date=?, status=? WHERE id=1`,
        [page_title || 'PRIVACY POLICY', effDate, status || 'published']
      );
    }

    // Replace sections
    await dbConnection.execute('DELETE FROM privacy_policy_sections WHERE page_id = 1');

    if (sections && Array.isArray(sections) && sections.length > 0) {
      for (let i = 0; i < sections.length; i++) {
        const sec = sections[i];
        if (!sec.section_title || !sec.section_html) continue;
        const slug = sec.section_slug || sec.section_title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');

        await dbConnection.execute(
          `INSERT INTO privacy_policy_sections (page_id, section_slug, section_title, section_html, sort_order) VALUES (1, ?, ?, ?, ?)`,
          [slug, sec.section_title, sec.section_html, sec.sort_order ?? i]
        );
      }
    }

    await dbConnection.commit();
    res.json({ message: 'Privacy policy updated successfully' });
  } catch (error) {
    await dbConnection.rollback();
    console.error('Error updating privacy policy:', error);
    res.status(500).json({ error: 'Failed to update privacy policy' });
  } finally {
    dbConnection.release();
  }
});

// Disclaimer Public
app.get('/api/disclaimer', async (req, res) => {
  try {
    const [pageRows] = await pool.execute('SELECT * FROM disclaimer_page WHERE id = 1 AND status = "published"');
    if (pageRows.length === 0) return res.status(404).json({ error: 'Disclaimer not found or not published' });

    const [sectionRows] = await pool.execute('SELECT * FROM disclaimer_sections WHERE page_id = 1 ORDER BY sort_order ASC, id ASC');
    res.json({ ...pageRows[0], sections: sectionRows });
  } catch (error) {
    console.error('Error fetching disclaimer:', error);
    res.status(500).json({ error: 'Failed to fetch disclaimer' });
  }
});

// Admin Disclaimer (Protected)
app.get('/api/admin/disclaimer', authenticateToken, async (req, res) => {
  try {
    const [pageRows] = await pool.execute('SELECT * FROM disclaimer_page WHERE id = 1');
    if (pageRows.length === 0) return res.status(404).json({ error: 'Disclaimer not found' });

    const [sectionRows] = await pool.execute('SELECT * FROM disclaimer_sections WHERE page_id = 1 ORDER BY sort_order ASC, id ASC');
    res.json({ ...pageRows[0], sections: sectionRows });
  } catch (error) {
    console.error('Error fetching disclaimer:', error);
    res.status(500).json({ error: 'Failed to fetch disclaimer' });
  }
});

app.put('/api/admin/disclaimer', authenticateToken, async (req, res) => {
  const { page_title, effective_date, status, sections } = req.body;
  const dbConnection = await pool.getConnection();
  try {
    await dbConnection.beginTransaction();

    const [existing] = await dbConnection.execute('SELECT id FROM disclaimer_page WHERE id = 1');
    const effDate = effective_date ? new Date(effective_date).toISOString().split('T')[0] : null;

    if (existing.length === 0) {
      await dbConnection.execute(
        `INSERT INTO disclaimer_page (id, page_title, effective_date, status) VALUES (1, ?, ?, ?)`,
        [page_title || 'DISCLAIMER', effDate, status || 'published']
      );
    } else {
      await dbConnection.execute(
        `UPDATE disclaimer_page SET page_title=?, effective_date=?, status=? WHERE id=1`,
        [page_title || 'DISCLAIMER', effDate, status || 'published']
      );
    }

    // Replace sections
    await dbConnection.execute('DELETE FROM disclaimer_sections WHERE page_id = 1');

    if (sections && Array.isArray(sections) && sections.length > 0) {
      for (let i = 0; i < sections.length; i++) {
        const sec = sections[i];
        if (!sec.section_title || !sec.section_html) continue;
        const slug = sec.section_slug || sec.section_title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');

        await dbConnection.execute(
          `INSERT INTO disclaimer_sections (page_id, section_slug, section_title, section_html, sort_order) VALUES (1, ?, ?, ?, ?)`,
          [slug, sec.section_title, sec.section_html, sec.sort_order ?? i]
        );
      }
    }

    await dbConnection.commit();
    res.json({ message: 'Disclaimer updated successfully' });
  } catch (error) {
    await dbConnection.rollback();
    console.error('Error updating disclaimer:', error);
    res.status(500).json({ error: 'Failed to update disclaimer' });
  } finally {
    dbConnection.release();
  }
});

// Chairman Message Public
app.get('/api/chairman-message', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM chairman_message WHERE id = 1 AND status = "published"');
    if (rows.length === 0) return res.status(404).json({ error: 'Message not found' });
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching chairman message:', error);
    res.status(500).json({ error: 'Failed to fetch message' });
  }
});

// Admin Chairman Message (Protected)
app.get('/api/admin/chairman-message', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM chairman_message WHERE id = 1');
    if (rows.length === 0) return res.status(404).json({ error: 'Message not found' });
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching chairman message:', error);
    res.status(500).json({ error: 'Failed to fetch message' });
  }
});

app.put('/api/admin/chairman-message', authenticateToken, async (req, res) => {
  const { name, designation, subtitle, photo_url, message_title, message_body, focus_cards, status } = req.body;
  try {
    const [existing] = await pool.execute('SELECT id FROM chairman_message WHERE id = 1');
    const focusCardsStr = focus_cards ? JSON.stringify(focus_cards) : null;

    if (existing.length === 0) {
      await pool.execute(
        `INSERT INTO chairman_message (id, name, designation, subtitle, photo_url, message_title, message_body, focus_cards, status)
         VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [name, designation, subtitle, photo_url, message_title, message_body, focusCardsStr, status || 'published']
      );
    } else {
      await pool.execute(
        `UPDATE chairman_message
         SET name=?, designation=?, subtitle=?, photo_url=?, message_title=?, message_body=?, focus_cards=?, status=?
         WHERE id=1`,
        [name, designation, subtitle, photo_url, message_title, message_body, focusCardsStr, status || 'published']
      );
    }
    res.json({ message: 'Chairman message updated successfully' });
  } catch (error) {
    console.error('Error updating chairman message:', error);
    res.status(500).json({ error: 'Failed to update message' });
  }
});


// File Uploads (Protected)
// Generic Upload
const uploadGeneric = multer({ storage: storage, limits: { fileSize: 5 * 1024 * 1024 } });
app.post('/api/admin/upload', authenticateToken, uploadGeneric.single('image'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  const folder = req.body.folder || 'misc';
  // Use generic /uploads path, actual move to folder logic could go here but this meets the basic requirement
  res.json({ imageUrl: `/uploads/${req.file.filename}`, message: 'Image uploaded successfully' });
});

app.post('/api/admin/upload/hero', authenticateToken, uploadHero.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded or invalid type' });
  const relativeUrl = `/uploads/hero/${req.file.filename}`;
  res.json({ url: relativeUrl });
});

app.post('/api/admin/upload/favicon', authenticateToken, uploadFavicon.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded or invalid type' });
  const relativeUrl = `/uploads/favicon/${req.file.filename}`;
  res.json({ url: relativeUrl });
});

app.post('/api/admin/upload/leadership', authenticateToken, uploadLeadership.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded or invalid type' });
  const relativeUrl = `/uploads/leadership/${req.file.filename}`;
  res.json({ url: relativeUrl });
});

app.post('/api/admin/upload/news-banner', authenticateToken, uploadNewsBanner.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded or invalid type' });
  const relativeUrl = `/uploads/news-banner/${req.file.filename}`;
  res.json({ url: relativeUrl });
});

app.post('/api/admin/upload/news-pdf', authenticateToken, uploadNewsPdf.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded or invalid type' });
  const relativeUrl = `/uploads/news-pdf/${req.file.filename}`;
  res.json({ url: relativeUrl });
});

app.post('/api/admin/upload/event-flyer', authenticateToken, uploadEventFlyer.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded or invalid type' });
  const relativeUrl = `/uploads/events/${req.file.filename}`;
  res.json({ url: relativeUrl });
});

app.post('/api/admin/upload/program-banner', authenticateToken, uploadProgramBanner.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded or invalid type' });
  const relativeUrl = `/uploads/programs/${req.file.filename}`;
  res.json({ url: relativeUrl });
});

// Dashboard Stats
app.get('/api/admin/stats', authenticateToken, async (req, res) => {
  try {
    const [chapters] = await pool.execute('SELECT COUNT(*) as count FROM chapters');
    const [events] = await pool.execute('SELECT COUNT(*) as count FROM events WHERE event_date >= CURDATE()');
    const [members] = await pool.execute('SELECT COUNT(*) as count FROM member_applications WHERE status = "Approved"');
    const [partners] = await pool.execute('SELECT COUNT(*) as count FROM partners');

    // Also fetch recent activity (e.g., recent news or events)
    const [recent] = await pool.execute(
      'SELECT "New Chapter Added" as activity, created_at as date, "Completed" as status FROM chapters ORDER BY created_at DESC LIMIT 3'
    );

    res.json({
      totalChapters: chapters[0].count,
      upcomingEvents: events[0].count,
      activeMembers: members[0].count || 0,
      totalPartners: partners[0].count,
      recentActivity: recent
    });
  } catch (error) {
    console.error('Stats error:', error);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// POST /api/auth/setup-2fa - Admin setup 2FA
app.post('/api/auth/setup-2fa', async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  try {
    const [rows] = await pool.execute('SELECT * FROM admin_users WHERE username = ?', [username]);
    if (rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = rows[0];
    if (user.password !== password) {
       return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Generate a new secret
    const secret = authenticator.generateSecret();
    const otpauthUrl = authenticator.keyuri(username, 'FITIS Admin', secret);

    // Generate QR Code data URL
    const qrCodeDataUrl = await QRCode.toDataURL(otpauthUrl);

    res.json({ secret, qrCodeDataUrl });
  } catch (error) {
    console.error('2FA Setup error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/auth/confirm-2fa - Admin confirm 2FA setup
app.post('/api/auth/confirm-2fa', async (req, res) => {
  const { username, password, secret, otpToken } = req.body;

  if (!username || !password || !secret || !otpToken) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    const [rows] = await pool.execute('SELECT * FROM admin_users WHERE username = ?', [username]);
    if (rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = rows[0];
    if (user.password !== password) {
       return res.status(401).json({ error: 'Invalid credentials' });
    }

    const isValid = authenticator.verify({ token: otpToken, secret });
    if (!isValid) {
      return res.status(400).json({ error: 'Invalid OTP token' });
    }

    // Save secret to database
    await pool.execute('UPDATE admin_users SET two_factor_secret = ? WHERE id = ?', [secret, user.id]);

    const token = jwt.sign(
      { id: user.id, username: user.username },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({ message: '2FA setup successful', token, user: { id: user.id, username: user.username } });
  } catch (error) {
    console.error('2FA Confirm error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// ADMIN: POST /api/admin/community-members - Admin direct creation of member
const uploadCommunity = multer({ storage });
app.post('/api/admin/community-members', authenticateToken, uploadCommunity.fields([{ name: 'company_logo', maxCount: 1 }, { name: 'rep_image', maxCount: 1 }]), async (req, res) => {
  const {
    company_name,
    primary_chapter,
    secondary_chapter,
    fitis_membership_id,
    company_id,
    official_email,
    company_linkedin,
    website_link,
    services,
    rep_name,
    rep_email,
    rep_mobile,
    rep_designation
  } = req.body;

  if (!company_name || !official_email || !rep_email) {
    return res.status(400).json({ error: 'Company name, official email, and representative email are required' });
  }

  try {
    // Check if email already exists
    const [existing] = await pool.execute('SELECT * FROM member_community_requests WHERE official_email = ?', [official_email]);
    if (existing.length > 0) {
      return res.status(400).json({ error: 'An account with this Official Email already exists' });
    }

    const setPasswordToken = crypto.randomBytes(32).toString('hex');

    const company_logo_url = req.files && req.files['company_logo'] ? `/uploads/community/${req.files['company_logo'][0].filename}` : null;
    const rep_image_url = req.files && req.files['rep_image'] ? `/uploads/community/${req.files['rep_image'][0].filename}` : null;

    const [result] = await pool.execute(
      `INSERT INTO member_community_requests (
        company_name, primary_chapter, secondary_chapter, fitis_membership_id, company_id, 
        official_email, company_linkedin, website_link, services, company_logo_url,
        rep_name, rep_email, rep_mobile, rep_designation, rep_image_url, 
        status, password
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Approved', ?)`,
      [
        company_name, 
        primary_chapter || null, 
        secondary_chapter || null,
        fitis_membership_id || null, 
        company_id || null,
        official_email, 
        company_linkedin || null,
        website_link || null,
        services || null,
        company_logo_url,
        rep_name || null, 
        rep_email, 
        rep_mobile || null,
        rep_designation || null,
        rep_image_url,
        'PENDING_SETUP'
      ]
    );

    // Save token to otp_verifications for temporary storage since it expires
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
    await pool.execute(
      'INSERT INTO otp_verifications (email, otp, expires_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE otp = ?, expires_at = ?',
      [official_email, setPasswordToken, expiresAt, setPasswordToken, expiresAt]
    );

    // Send email to Representative
    const frontendUrl = process.env.FRONTEND_URL || `http://${req.headers.host || 'localhost:3000'}`;
    const setupLink = `${frontendUrl}/set-password?token=${setPasswordToken}&email=${encodeURIComponent(official_email)}`;
    await sendBrevoEmail(
      rep_email,
      rep_name || company_name,
      'Your FITIS Member Account has been Created',
      `
        <h3>Welcome to FITIS Community</h3>
        <p>An administrator has created a member account for your company: <strong>${company_name}</strong>.</p>
        <p>Your official login email is: <strong>${official_email}</strong></p>
        <br/>
        <p>Please click the link below to set up your password and access your account.</p>
        <p><a href="${setupLink}" style="padding: 10px 20px; background-color: #004a99; color: white; text-decoration: none; border-radius: 5px;">Set My Password</a></p>
        <br/>
        <p>This link expires in 24 hours.</p>
        <p>If the link above does not work, copy and paste the following URL into your browser:</p>
        <p>${setupLink}</p>
      `
    );

    res.json({ message: 'Member created successfully and setup email sent' });
  } catch (error) {
    console.error('Admin create member error:', error);
    res.status(500).json({ error: 'Failed to create member' });
  }
});


// ================= GALLERY APIs =================

// Public Gallery APIs
app.get('/api/gallery', async (req, res) => {
  try {
    const status = req.query.status || 'published';

    // Fetch posts
    const [posts] = await pool.execute('SELECT * FROM gallery_posts WHERE status = ? ORDER BY event_date DESC, created_at DESC', [status]);

    // Fetch all images per post
    for (let post of posts) {
      const [images] = await pool.execute('SELECT * FROM gallery_images WHERE post_id = ? ORDER BY sort_order ASC', [post.id]);
      post.images = images;
      post.cover_image = images.length > 0 ? images[0].image_url : null;
    }

    res.json(posts);
  } catch (error) {
    console.error('Error fetching gallery:', error);
    res.status(500).json({ error: 'Failed to fetch gallery' });
  }
});

app.get('/api/gallery/:id', async (req, res) => {
  try {
    const [posts] = await pool.execute('SELECT * FROM gallery_posts WHERE id = ?', [req.params.id]);
    if (posts.length === 0) return res.status(404).json({ error: 'Gallery post not found' });

    const post = posts[0];
    const [images] = await pool.execute('SELECT * FROM gallery_images WHERE post_id = ? ORDER BY sort_order ASC', [post.id]);
    post.images = images;

    res.json(post);
  } catch (error) {
    console.error('Error fetching gallery details:', error);
    res.status(500).json({ error: 'Failed to fetch gallery details' });
  }
});

// Admin Gallery APIs (Protected)
app.get('/api/admin/gallery', authenticateToken, async (req, res) => {
  try {
    const [posts] = await pool.execute('SELECT * FROM gallery_posts ORDER BY created_at DESC');
    res.json(posts);
  } catch (error) {
    console.error('Error fetching admin gallery:', error);
    res.status(500).json({ error: 'Failed to fetch gallery posts' });
  }
});

app.get('/api/admin/gallery/:id', authenticateToken, async (req, res) => {
  try {
    const [posts] = await pool.execute('SELECT * FROM gallery_posts WHERE id = ?', [req.params.id]);
    if (posts.length === 0) return res.status(404).json({ error: 'Gallery post not found' });

    const post = posts[0];
    const [images] = await pool.execute('SELECT * FROM gallery_images WHERE post_id = ? ORDER BY sort_order ASC', [post.id]);
    post.images = images;

    res.json(post);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch gallery post' });
  }
});

app.post('/api/admin/gallery', authenticateToken, async (req, res) => {
  const { title, description, event_date, status } = req.body;
  if (!title) return res.status(400).json({ error: 'Title is required' });

  let formattedDate = null;
  if (event_date && event_date.trim() !== '') {
    try {
      formattedDate = new Date(event_date).toISOString().split('T')[0];
    } catch (e) {
      formattedDate = null;
    }
  }

  try {
    const [result] = await pool.execute(
      `INSERT INTO gallery_posts (title, description, event_date, status) VALUES (?, ?, ?, ?)`,
      [title, description || null, formattedDate, status || 'draft']
    );
    const [newPost] = await pool.execute('SELECT * FROM gallery_posts WHERE id = ?', [result.insertId]);
    res.status(201).json(newPost[0]);
  } catch (error) {
    console.error('Error creating gallery post:', error);
    res.status(500).json({ error: 'Failed to create gallery post' });
  }
});

app.put('/api/admin/gallery/:id', authenticateToken, async (req, res) => {
  const { title, description, event_date, status } = req.body;
  const { id } = req.params;

  let formattedDate = null;
  if (event_date && event_date.trim() !== '') {
    try {
      formattedDate = new Date(event_date).toISOString().split('T')[0];
    } catch (e) {
      formattedDate = null;
    }
  }

  try {
    const [result] = await pool.execute(
      `UPDATE gallery_posts SET title=?, description=?, event_date=?, status=? WHERE id=?`,
      [title, description || null, formattedDate, status || 'draft', id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Gallery post not found' });
    res.json({ message: 'Gallery post updated' });
  } catch (error) {
    console.error('Error updating gallery post:', error);
    res.status(500).json({ error: 'Failed to update gallery post' });
  }
});

app.delete('/api/admin/gallery/:id', authenticateToken, async (req, res) => {
  try {
    // The foreign key constraint ON DELETE CASCADE will handle deleting images in the DB.
    // However, the actual files in /uploads/gallery/ will remain orphaned unless manually deleted.
    // For this scope, DB cascading is sufficient.
    const [result] = await pool.execute('DELETE FROM gallery_posts WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Gallery post not found' });
    res.json({ message: 'Gallery post deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete gallery post' });
  }
});

// Admin Delete Single Image
app.delete('/api/admin/gallery/images/:imageId', authenticateToken, async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM gallery_images WHERE id = ?', [req.params.imageId]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Image not found' });
    res.json({ message: 'Image deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete image' });
  }
});

// Admin Reorder Images
app.put('/api/admin/gallery/:id/images/reorder', authenticateToken, async (req, res) => {
  const { images } = req.body; // Expects an array of objects: { id: 1, sort_order: 1 }
  if (!images || !Array.isArray(images)) return res.status(400).json({ error: 'Invalid data format' });

  try {
    // Perform updates in a loop (could use transactions for safety, but simple loop works for this scope)
    for (const img of images) {
      await pool.execute('UPDATE gallery_images SET sort_order = ? WHERE id = ?', [img.sort_order, img.id]);
    }
    res.json({ message: 'Images reordered successfully' });
  } catch (error) {
    console.error('Error reordering images:', error);
    res.status(500).json({ error: 'Failed to reorder images' });
  }
});


app.get('/api/admin/member_applications', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM member_applications ORDER BY created_at DESC');
    res.status(200).json(rows);
  } catch (error) {
    console.error('Error fetching member_applications:', error);
    if (error.code === 'ER_NO_SUCH_TABLE') {
      return res.status(500).json({ message: 'DB table missing' });
    }
    res.status(500).json({ message: error.message });
  }
});

// Member Benefits specific routes (mapping 'member-benefits' to 'member_benefits' table)
app.get('/api/admin/member-benefits', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM member_benefits ORDER BY sort_order ASC, created_at DESC');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching member_benefits:', error);
    res.status(500).json({ message: error.message });
  }
});

app.get('/api/admin/member-benefits/:id', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM member_benefits WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Item not found' });
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.post('/api/admin/member-benefits', authenticateToken, async (req, res) => {
  const data = req.body;
  if (!data || Object.keys(data).length === 0) return res.status(400).json({ error: 'No data provided' });

  const allowedColumns = TABLE_COLUMNS['member_benefits'];
  const safeData = {};
  for (const key of Object.keys(data)) {
    if (allowedColumns.includes(key)) {
      safeData[key] = data[key];
    }
  }

  if (Object.keys(safeData).length === 0) return res.status(400).json({ error: 'No valid data provided' });

  const columns = Object.keys(safeData).join(', ');
  const placeholders = Object.keys(safeData).map(() => '?').join(', ');
  const values = Object.values(safeData);

  try {
    const [result] = await pool.execute(`INSERT INTO member_benefits (${columns}) VALUES (${placeholders})`, values);
    const [newItem] = await pool.execute('SELECT * FROM member_benefits WHERE id = ?', [result.insertId]);
    res.status(201).json(newItem[0]);
  } catch (error) {
    console.error('Error creating member_benefits:', error);
    res.status(500).json({ message: error.message });
  }
});

app.put('/api/admin/member-benefits/:id', authenticateToken, async (req, res) => {
  const { id } = req.params;
  const data = req.body;
  if (!data || Object.keys(data).length === 0) return res.status(400).json({ error: 'No data provided' });

  const allowedColumns = TABLE_COLUMNS['member_benefits'];
  const safeData = {};
  for (const key of Object.keys(data)) {
    if (allowedColumns.includes(key)) {
      safeData[key] = data[key];
    }
  }

  if (Object.keys(safeData).length === 0) return res.status(400).json({ error: 'No valid data provided' });

  const updates = Object.keys(safeData).map(key => `${key} = ?`).join(', ');
  const values = [...Object.values(safeData), id];

  try {
    const [result] = await pool.execute(`UPDATE member_benefits SET ${updates} WHERE id = ?`, values);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Item not found' });

    const [updatedItem] = await pool.execute('SELECT * FROM member_benefits WHERE id = ?', [id]);
    res.json(updatedItem[0]);
  } catch (error) {
    console.error('Error updating member_benefits:', error);
    res.status(500).json({ message: error.message });
  }
});

app.delete('/api/admin/member-benefits/:id', authenticateToken, async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM member_benefits WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Item not found' });
    res.json({ message: 'Item deleted successfully' });
  } catch (error) {
    console.error('Error deleting member_benefits:', error);
    res.status(500).json({ message: error.message });
  }
});

// Generic GET all items

// --- CUSTOM CHAPTERS ROUTES ---

app.get('/api/admin/chapters', authenticateToken, async (req, res) => {
  try {
    const [chapters] = await pool.execute('SELECT * FROM chapters ORDER BY sort_order ASC, id DESC');
    res.json(chapters);
  } catch (error) {
    console.error('Error fetching chapters:', error);
    res.status(500).json({ error: 'Failed to fetch chapters' });
  }
});

app.get('/api/admin/chapters/:id', authenticateToken, async (req, res) => {
  try {
    const [chapterRows] = await pool.execute('SELECT * FROM chapters WHERE id = ?', [req.params.id]);
    if (chapterRows.length === 0) return res.status(404).json({ error: 'Chapter not found' });

    const chapter = chapterRows[0];

    const [committeeRows] = await pool.execute('SELECT * FROM chapter_committee WHERE chapter_id = ? ORDER BY display_order ASC, id ASC', [chapter.id]);
    chapter.committee = committeeRows;

    res.json(chapter);
  } catch (error) {
    console.error('Error fetching chapter details:', error);
    res.status(500).json({ error: 'Failed to fetch chapter' });
  }
});

app.post('/api/admin/chapters', authenticateToken, async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const data = req.body;

    // Auto-generate slug if missing
    if (!data.slug && data.name) {
      data.slug = data.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '') + '-' + Date.now().toString().slice(-6);
    }

    const chapterFields = [
      'name', 'slug', 'summary', 'about_chapter', 'banner_image_url', 'thumbnail_image_url',
      'chair_name', 'chair_title', 'chair_message', 'chair_image_url',
      'contact_email', 'contact_phone', 'has_committee', 'status', 'sort_order'
    ];

    const safeData = {};
    for (const key of chapterFields) {
      if (data[key] !== undefined) {
        safeData[key] = data[key];
      }
    }

    // Handle has_committee bool conversion if needed
    if (safeData.has_committee !== undefined) {
      safeData.has_committee = safeData.has_committee === true || safeData.has_committee === 'true' || safeData.has_committee === 1;
    }

    const columns = Object.keys(safeData).join(', ');
    const placeholders = Object.keys(safeData).map(() => '?').join(', ');
    const values = Object.values(safeData);

    const [result] = await conn.execute(`INSERT INTO chapters (${columns}) VALUES (${placeholders})`, values);
    const chapterId = result.insertId;

    if (safeData.has_committee && data.committee && Array.isArray(data.committee)) {
      for (const member of data.committee) {
        await conn.execute(
          `INSERT INTO chapter_committee (chapter_id, name, designation, company, role_label, image_url, linkedin_url, display_order)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            chapterId,
            member.name || '',
            member.designation || null,
            member.company || null,
            member.role_label || null,
            member.image_url || null,
            member.linkedin_url || null,
            member.display_order || 0
          ]
        );
      }
    }

    await conn.commit();
    res.status(201).json({ id: chapterId, ...safeData });
  } catch (error) {
    await conn.rollback();
    console.error('Error creating chapter:', error);
    res.status(500).json({ error: 'Failed to create chapter' });
  } finally {
    conn.release();
  }
});

app.put('/api/admin/chapters/:id', authenticateToken, async (req, res) => {
  const chapterId = req.params.id;
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const data = req.body;

    const chapterFields = [
      'name', 'slug', 'summary', 'about_chapter', 'banner_image_url', 'thumbnail_image_url',
      'chair_name', 'chair_title', 'chair_message', 'chair_image_url',
      'contact_email', 'contact_phone', 'has_committee', 'status', 'sort_order'
    ];

    const safeData = {};
    for (const key of chapterFields) {
      if (data[key] !== undefined) {
        safeData[key] = data[key];
      }
    }

    if (safeData.has_committee !== undefined) {
      safeData.has_committee = safeData.has_committee === true || safeData.has_committee === 'true' || safeData.has_committee === 1;
    }

    if (Object.keys(safeData).length > 0) {
      const updates = Object.keys(safeData).map(key => `${key} = ?`).join(', ');
      const values = Object.values(safeData);
      values.push(chapterId);

      await conn.execute(`UPDATE chapters SET ${updates} WHERE id = ?`, values);
    }

    // Always replace committee members to keep it simple
    await conn.execute('DELETE FROM chapter_committee WHERE chapter_id = ?', [chapterId]);

    if (safeData.has_committee && data.committee && Array.isArray(data.committee)) {
      for (const member of data.committee) {
        await conn.execute(
          `INSERT INTO chapter_committee (chapter_id, name, designation, company, role_label, image_url, linkedin_url, display_order)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            chapterId,
            member.name || '',
            member.designation || null,
            member.company || null,
            member.role_label || null,
            member.image_url || null,
            member.linkedin_url || null,
            member.display_order || 0
          ]
        );
      }
    }

    await conn.commit();
    res.json({ message: 'Chapter updated successfully' });
  } catch (error) {
    await conn.rollback();
    console.error('Error updating chapter:', error);
    res.status(500).json({ error: 'Failed to update chapter' });
  } finally {
    conn.release();
  }
});

app.delete('/api/admin/chapters/:id', authenticateToken, async (req, res) => {
  try {
    // ON DELETE CASCADE will handle chapter_committee rows
    const [result] = await pool.execute('DELETE FROM chapters WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Chapter not found' });
    res.json({ message: 'Chapter deleted' });
  } catch (error) {
    console.error('Error deleting chapter:', error);
    res.status(500).json({ error: 'Failed to delete chapter' });
  }
});

// --- END CUSTOM CHAPTERS ROUTES ---

app.get('/api/admin/:table', authenticateToken, async (req, res) => {
  const { table } = req.params;
  if (!ALLOWED_TABLES.includes(table)) return res.status(404).json({ message: 'Route not found' });

  try {
    const orderColumn = table === 'newsletter_subscribers' ? 'subscribed_at' : 'created_at';
    const [rows] = await pool.execute(`SELECT * FROM ${table} ORDER BY ${orderColumn} DESC`);
    res.json(rows);
  } catch (error) {
    console.error(`Error fetching ${table}:`, error);
    res.status(500).json({ message: error.message });
  }
});

// Generic GET single item
app.get('/api/admin/:table/:id', authenticateToken, async (req, res) => {
  const { table, id } = req.params;
  if (!ALLOWED_TABLES.includes(table)) return res.status(404).json({ message: 'Route not found' });

  try {
    const [rows] = await pool.execute(`SELECT * FROM ${table} WHERE id = ?`, [id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Item not found' });
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Generic POST create item
app.post('/api/admin/:table', authenticateToken, async (req, res) => {
  const { table } = req.params;
  if (!ALLOWED_TABLES.includes(table)) return res.status(404).json({ message: 'Route not found' });

  const data = req.body;
  if (!data || Object.keys(data).length === 0) return res.status(400).json({ error: 'No data provided' });

  // Filter keys against allowed columns whitelist
  const allowedColumns = TABLE_COLUMNS[table];
  const safeData = {};
  for (const key of Object.keys(data)) {
    if (allowedColumns.includes(key)) {
      safeData[key] = data[key];
    }
  }

  // Auto-generate slug if missing
  if (allowedColumns.includes('slug') && !safeData.slug && safeData.title) {
    safeData.slug = safeData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '') + '-' + Date.now().toString().slice(-6);
  }

  if (Object.keys(safeData).length === 0) return res.status(400).json({ error: 'No valid data provided' });

  const columns = Object.keys(safeData).join(', ');
  const placeholders = Object.keys(safeData).map(() => '?').join(', ');
  const values = Object.values(safeData);

  try {
    const [result] = await pool.execute(`INSERT INTO ${table} (${columns}) VALUES (${placeholders})`, values);
    const [newItem] = await pool.execute(`SELECT * FROM ${table} WHERE id = ?`, [result.insertId]);
    res.status(201).json(newItem[0]);
  } catch (error) {
    console.error(`Error creating in ${table}:`, error);
    res.status(500).json({ message: error.message });
  }
});

// Upload Chairman Photo
app.post('/api/admin/upload/chairman-photo', authenticateToken, uploadChairmanPhoto.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const relativePath = `/uploads/chairman/${req.file.filename}`;
  res.json({ url: relativePath });
});

// Upload Secretariat Photo
app.post('/api/admin/upload/secretariat-photo', authenticateToken, uploadSecretariatPhoto.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const relativePath = `/uploads/secretariat/${req.file.filename}`;
  res.json({ url: relativePath });
});

// Upload Newsletter Cover
app.post('/api/admin/upload/newsletter-cover', authenticateToken, uploadNewsletterCover.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const relativePath = `/uploads/newsletters/${req.file.filename}`;
  res.json({ url: relativePath });
});

// Upload Newsletter PDF
app.post('/api/admin/upload/newsletter-pdf', authenticateToken, uploadNewsletterPdf.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const relativePath = `/uploads/newsletters/${req.file.filename}`;
  res.json({ url: relativePath });
});

// Public GET Newsletters
app.get('/api/newsletters', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM newsletters WHERE status = "published" ORDER BY published_date DESC, sort_order ASC');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching newsletters:', error);
    res.status(500).json({ error: 'Failed to fetch newsletters' });
  }
});

// Upload Partner Logo
app.post('/api/admin/upload/partner-logo', authenticateToken, uploadPartnerLogo.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const relativePath = `/uploads/partners/${req.file.filename}`;
  res.json({ url: relativePath });
});

// Upload Member Benefit Logo
app.post('/api/admin/upload/member-benefit-logo', authenticateToken, uploadBenefitLogo.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const relativePath = `/uploads/benefits/${req.file.filename}`;
  res.json({ url: relativePath });
});

// Upload Chapter Icon
app.post('/api/admin/upload/chapter-icon', authenticateToken, uploadChapterIcon.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const relativePath = `/uploads/chapters/${req.file.filename}`;
  res.json({ url: relativePath });
});

// Generic PUT update item
app.put('/api/admin/:table/:id', authenticateToken, async (req, res) => {
  const { table, id } = req.params;
  if (!ALLOWED_TABLES.includes(table)) return res.status(404).json({ message: 'Route not found' });

  const data = req.body;
  if (!data || Object.keys(data).length === 0) return res.status(400).json({ error: 'No data provided' });

  // Filter keys against allowed columns whitelist
  const allowedColumns = TABLE_COLUMNS[table];
  const safeData = {};
  for (const key of Object.keys(data)) {
    if (allowedColumns.includes(key)) {
      safeData[key] = data[key];
    }
  }

  // Auto-generate slug if missing
  if (allowedColumns.includes('slug') && !safeData.slug && safeData.title) {
    safeData.slug = safeData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '') + '-' + Date.now().toString().slice(-6);
  }

  if (Object.keys(safeData).length === 0) return res.status(400).json({ error: 'No valid data provided' });

  const updates = Object.keys(safeData).map(key => `${key} = ?`).join(', ');
  const values = [...Object.values(safeData), id];

  try {
    const [result] = await pool.execute(`UPDATE ${table} SET ${updates} WHERE id = ?`, values);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Item not found' });

    const [updatedItem] = await pool.execute(`SELECT * FROM ${table} WHERE id = ?`, [id]);
    res.json(updatedItem[0]);
  } catch (error) {
    console.error(`Error updating ${table}:`, error);
    res.status(500).json({ message: error.message });
  }
});

// Generic DELETE item
app.delete('/api/admin/:table/:id', authenticateToken, async (req, res) => {
  const { table, id } = req.params;
  if (!ALLOWED_TABLES.includes(table)) return res.status(404).json({ message: 'Route not found' });

  try {
    const [result] = await pool.execute(`DELETE FROM ${table} WHERE id = ?`, [id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Item not found' });
    res.json({ message: 'Item deleted successfully' });
  } catch (error) {
    console.error(`Error deleting from ${table}:`, error);
    res.status(500).json({ message: error.message });
  }
});

// Public Partners
app.get('/api/partners', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM partners WHERE status = "published" ORDER BY sort_order ASC, created_at DESC');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching partners:', error);
    res.status(500).json({ error: 'Failed to fetch partners' });
  }
});

// Public Secretariat Team
app.get('/api/secretariat-team', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM secretariat_team WHERE status = "published" ORDER BY sort_order ASC, created_at DESC');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching secretariat team:', error);
    res.status(500).json({ error: 'Failed to fetch secretariat team' });
  }
});

// Public Leadership Members
app.get('/api/leadership-members', async (req, res) => {
  try {
    const type = req.query.type;
    let query = 'SELECT * FROM leadership_members';
    let params = [];

    if (type === 'past') {
      query += ' WHERE type = "past" AND status = "published" ORDER BY sort_order ASC';
    } else if (type === 'current') {
      query += ' WHERE type = "current" AND status = "published" ORDER BY hierarchy_level ASC, seat ASC';
    } else {
      query += ' WHERE status = "published" ORDER BY type ASC, hierarchy_level ASC, seat ASC';
    }

    const [rows] = await pool.execute(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching leadership members:', error);
    res.status(500).json({ error: 'Failed to fetch leadership members' });
  }
});

// Public Chapters API
app.get('/api/chapters', async (req, res) => {
  try {
    const status = req.query.status || 'active';
    const [rows] = await pool.execute('SELECT * FROM chapters WHERE status = ? ORDER BY sort_order ASC, created_at DESC', [status]);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching chapters:', error);
    res.status(500).json({ error: 'Failed to fetch chapters' });
  }
});

app.get('/api/chapters/:slug', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM chapters WHERE slug = ? AND status = "active"', [req.params.slug]);
    if (rows.length === 0) return res.status(404).json({ error: 'Chapter not found' });

    const chapter = rows[0];
    const [committeeRows] = await pool.execute('SELECT * FROM chapter_committee WHERE chapter_id = ? ORDER BY display_order ASC, id ASC', [chapter.id]);
    chapter.committee = committeeRows;

    res.json(chapter);
  } catch (error) {
    console.error('Error fetching chapter:', error);
    res.status(500).json({ error: 'Failed to fetch chapter' });
  }
});

// Public Member Benefits
app.get('/api/member-benefits', async (req, res) => {
  try {
    const status = req.query.status || 'published';
    const category = req.query.category;
    const search = req.query.search;

    let query = 'SELECT * FROM member_benefits WHERE status = ?';
    let params = [status];

    if (category && category !== 'All') {
      query += ' AND category = ?';
      params.push(category);
    }

    if (search) {
      query += ' AND (brand_name LIKE ? OR benefit_title LIKE ? OR description LIKE ?)';
      const searchParam = `%${search}%`;
      params.push(searchParam, searchParam, searchParam);
    }

    query += ' ORDER BY sort_order ASC, created_at DESC';

    const [rows] = await pool.execute(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching member benefits:', error);
    res.status(500).json({ error: 'Failed to fetch member benefits' });
  }
});

// Public Events API
app.get('/api/events', async (req, res) => {
  try {
    const status = req.query.status || 'published';
    const [rows] = await pool.execute('SELECT * FROM events WHERE status = ? ORDER BY event_date ASC', [status]);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching events:', error);
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});

// Public News API
app.get('/api/news', async (req, res) => {
  try {
    const status = req.query.status || 'published';
    const q = req.query.q;

    let query = 'SELECT id, title, slug, excerpt, banner_image_url, category, publish_date FROM news WHERE status = ?';
    let params = [status];

    if (q) {
      query += ' AND (title LIKE ? OR excerpt LIKE ? OR content LIKE ?)';
      const searchParam = `%${q}%`;
      params.push(searchParam, searchParam, searchParam);
    }

    query += ' ORDER BY publish_date DESC, created_at DESC';

    const [rows] = await pool.execute(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching news:', error);
    res.status(500).json({ error: 'Failed to fetch news' });
  }
});

app.get('/api/news/:slug', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM news WHERE slug = ? AND status = ?', [req.params.slug, 'published']);
    if (rows.length === 0) return res.status(404).json({ error: 'News article not found' });
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching news article:', error);
    res.status(500).json({ error: 'Failed to fetch news article' });
  }
});

// Public Programs API
app.get('/api/programs', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM programs WHERE status = "published" ORDER BY sort_order ASC, created_at DESC');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching programs:', error);
    res.status(500).json({ error: 'Failed to fetch programs' });
  }
});

app.get('/api/programs/:slug', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM programs WHERE slug = ? AND status = "published"', [req.params.slug]);
    if (rows.length === 0) return res.status(404).json({ error: 'Program not found' });
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching program:', error);
    res.status(500).json({ error: 'Failed to fetch program' });
  }
});

// Get related news
app.get('/api/news/:slug/related', async (req, res) => {
  try {
    const [current] = await pool.execute('SELECT category FROM news WHERE slug = ?', [req.params.slug]);
    if (current.length === 0) return res.status(404).json({ error: 'News article not found' });

    const category = current[0].category;

    const [rows] = await pool.execute(
      'SELECT id, title, slug, excerpt, banner_image_url, category, publish_date FROM news WHERE status = ? AND slug != ? AND category = ? ORDER BY publish_date DESC, created_at DESC LIMIT 3',
      ['published', req.params.slug, category]
    );

    if (rows.length < 3) {
      const needed = 3 - rows.length;
      const [moreRows] = await pool.execute(
        'SELECT id, title, slug, excerpt, banner_image_url, category, publish_date FROM news WHERE status = ? AND slug != ? AND category != ? ORDER BY publish_date DESC, created_at DESC LIMIT ?',
        ['published', req.params.slug, category, needed]
      );
      res.json([...rows, ...moreRows]);
    } else {
      res.json(rows);
    }
  } catch (error) {
    console.error('Error fetching related news:', error);
    res.status(500).json({ error: 'Failed to fetch related news' });
  }
});

// =====================================================
// GALLERY MANAGEMENT
// =====================================================

// Ensure gallery tables exist
pool.query(`
  CREATE TABLE IF NOT EXISTS gallery_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    event_date DATE,
    status ENUM('draft', 'published') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  )
`).then(() => console.log('gallery_posts table ensured')).catch(err => console.error('Error creating gallery_posts table:', err));

pool.query(`
  CREATE TABLE IF NOT EXISTS gallery_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    image_url VARCHAR(500) NOT NULL,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES gallery_posts(id) ON DELETE CASCADE
  )
`).then(() => console.log('gallery_images table ensured')).catch(err => console.error('Error creating gallery_images table:', err));

// ADMIN: GET /api/admin/gallery - List all gallery posts
app.get('/api/admin/gallery', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT id, title, description, event_date, status, created_at FROM gallery_posts ORDER BY event_date DESC, created_at DESC'
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching gallery posts:', error);
    res.status(500).json({ error: 'Failed to fetch gallery posts' });
  }
});

// ADMIN: GET /api/admin/gallery/:id - Get single gallery post with images
app.get('/api/admin/gallery/:id', authenticateToken, async (req, res) => {
  try {
    const [posts] = await pool.execute('SELECT * FROM gallery_posts WHERE id = ?', [req.params.id]);
    if (posts.length === 0) return res.status(404).json({ error: 'Gallery post not found' });

    const [images] = await pool.execute(
      'SELECT * FROM gallery_images WHERE post_id = ? ORDER BY sort_order ASC',
      [req.params.id]
    );
    res.json({ ...posts[0], images });
  } catch (error) {
    console.error('Error fetching gallery post:', error);
    res.status(500).json({ error: 'Failed to fetch gallery post' });
  }
});

// ADMIN: POST /api/admin/gallery - Create new gallery post
app.post('/api/admin/gallery', authenticateToken, async (req, res) => {
  try {
    const { title, description, event_date, status } = req.body;
    if (!title) return res.status(400).json({ error: 'Title is required' });

    const [result] = await pool.execute(
      'INSERT INTO gallery_posts (title, description, event_date, status) VALUES (?, ?, ?, ?)',
      [title, description || null, event_date || null, status || 'draft']
    );
    const [rows] = await pool.execute('SELECT * FROM gallery_posts WHERE id = ?', [result.insertId]);
    res.status(201).json({ ...rows[0], images: [] });
  } catch (error) {
    console.error('Error creating gallery post:', error);
    res.status(500).json({ error: 'Failed to create gallery post' });
  }
});

// ADMIN: PUT /api/admin/gallery/:id - Update gallery post
app.put('/api/admin/gallery/:id', authenticateToken, async (req, res) => {
  try {
    const { title, description, status } = req.body;
    // Sanitize event_date: accept YYYY-MM-DD strings, Date objects, or null
    let event_date = req.body.event_date || null;
    if (event_date) {
      // Strip time component if present (e.g. from MySQL Date object serialized as ISO string)
      if (typeof event_date === 'string') {
        event_date = event_date.split('T')[0]; // keep only YYYY-MM-DD
      } else if (event_date instanceof Date) {
        event_date = event_date.toISOString().split('T')[0];
      }
    }

    const validStatus = (status === 'published' || status === 'draft') ? status : 'draft';

    await pool.execute(
      'UPDATE gallery_posts SET title = ?, description = ?, event_date = ?, status = ? WHERE id = ?',
      [title || '', description || null, event_date, validStatus, req.params.id]
    );
    res.json({ success: true });
  } catch (error) {
    console.error('Error updating gallery post:', error);
    res.status(500).json({ error: error.message || 'Failed to update gallery post' });
  }
});

// IMPORTANT: DELETE /images/:imageId MUST come before DELETE /:id to avoid Express
// matching 'images' as the :id param on the gallery post route.

// ADMIN: DELETE /api/admin/gallery/images/:imageId - Delete a single image
app.delete('/api/admin/gallery/images/:imageId', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT image_url FROM gallery_images WHERE id = ?', [req.params.imageId]);
    if (rows.length === 0) return res.status(404).json({ error: 'Image not found' });

    // Delete file from disk
    const filePath = path.join(process.cwd(), rows[0].image_url);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

    await pool.execute('DELETE FROM gallery_images WHERE id = ?', [req.params.imageId]);
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting gallery image:', error);
    res.status(500).json({ error: error.message || 'Failed to delete image' });
  }
});

// ADMIN: DELETE /api/admin/gallery/:id - Delete gallery post (images are cascade deleted)
app.delete('/api/admin/gallery/:id', authenticateToken, async (req, res) => {
  try {
    // Fetch images to delete files from disk
    const [images] = await pool.execute('SELECT image_url FROM gallery_images WHERE post_id = ?', [req.params.id]);
    images.forEach(img => {
      const filePath = path.join(process.cwd(), img.image_url);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    });

    await pool.execute('DELETE FROM gallery_posts WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting gallery post:', error);
    res.status(500).json({ error: error.message || 'Failed to delete gallery post' });
  }
});

// ADMIN: POST /api/admin/gallery/:id/images - Upload images for a post
app.post('/api/admin/gallery/:id/images', authenticateToken, uploadGallery.array('files', 50), async (req, res) => {
  try {
    const post_id = req.params.id;

    // Ensure post exists
    const [posts] = await pool.execute('SELECT id FROM gallery_posts WHERE id = ?', [post_id]);
    if (posts.length === 0) return res.status(404).json({ error: 'Gallery post not found' });

    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: 'No files uploaded' });
    }

    // Get current max sort_order
    const [maxOrder] = await pool.execute(
      'SELECT COALESCE(MAX(sort_order), 0) AS max_order FROM gallery_images WHERE post_id = ?',
      [post_id]
    );
    let currentOrder = maxOrder[0].max_order;

    const insertedImages = [];
    for (const file of req.files) {
      currentOrder++;
      const image_url = `/uploads/gallery/${file.filename}`;
      const [result] = await pool.execute(
        'INSERT INTO gallery_images (post_id, image_url, sort_order) VALUES (?, ?, ?)',
        [post_id, image_url, currentOrder]
      );
      insertedImages.push({ id: result.insertId, post_id: parseInt(post_id), image_url, sort_order: currentOrder });
    }

    res.status(201).json({ images: insertedImages });
  } catch (error) {
    console.error('Error uploading gallery images:', error);
    res.status(500).json({ error: 'Failed to upload images' });
  }
});

// (DELETE /images/:imageId was moved above DELETE /:id to fix Express route ordering)

// ADMIN: PUT /api/admin/gallery/:id/images/reorder - Reorder images
app.put('/api/admin/gallery/:id/images/reorder', authenticateToken, async (req, res) => {
  try {
    const { images } = req.body; // Array of { id, sort_order }
    if (!Array.isArray(images)) return res.status(400).json({ error: 'images array is required' });

    for (const img of images) {
      await pool.execute('UPDATE gallery_images SET sort_order = ? WHERE id = ? AND post_id = ?', [img.sort_order, img.id, req.params.id]);
    }
    res.json({ success: true });
  } catch (error) {
    console.error('Error reordering gallery images:', error);
    res.status(500).json({ error: 'Failed to reorder images' });
  }
});

// PUBLIC: GET /api/gallery - List all published gallery posts
app.get('/api/gallery', async (req, res) => {
  try {
    const [posts] = await pool.execute(
      'SELECT id, title, description, event_date, status FROM gallery_posts WHERE status = ? ORDER BY event_date DESC, created_at DESC',
      ['published']
    );

    // Attach first image as thumbnail for each post
    const postsWithThumbs = await Promise.all(posts.map(async (post) => {
      const [images] = await pool.execute(
        'SELECT id, image_url FROM gallery_images WHERE post_id = ? ORDER BY sort_order ASC LIMIT 1',
        [post.id]
      );
      return { ...post, thumbnail: images[0] || null };
    }));

    res.json(postsWithThumbs);
  } catch (error) {
    console.error('Error fetching public gallery:', error);
    res.status(500).json({ error: 'Failed to fetch gallery' });
  }
});

// PUBLIC: GET /api/gallery/:id - Get single published gallery post with all images
app.get('/api/gallery/:id', async (req, res) => {
  try {
    const [posts] = await pool.execute(
      'SELECT id, title, description, event_date FROM gallery_posts WHERE id = ? AND status = ?',
      [req.params.id, 'published']
    );
    if (posts.length === 0) return res.status(404).json({ error: 'Gallery not found' });

    const [images] = await pool.execute(
      'SELECT * FROM gallery_images WHERE post_id = ? ORDER BY sort_order ASC',
      [req.params.id]
    );
    res.json({ ...posts[0], images });
  } catch (error) {
    console.error('Error fetching public gallery post:', error);
    res.status(500).json({ error: 'Failed to fetch gallery post' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
